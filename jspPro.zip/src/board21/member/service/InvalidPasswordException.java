package board21.member.service;

public class InvalidPasswordException extends RuntimeException{

	
}
