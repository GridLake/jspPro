package board21.member.service;

public class MemberNotFoundException extends RuntimeException{

	
}
