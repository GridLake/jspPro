package board21.auth.service;

public class LoginFailException extends RuntimeException {

	
}
